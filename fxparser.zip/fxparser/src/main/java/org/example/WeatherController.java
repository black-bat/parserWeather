package org.example;

import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.util.*;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WeatherController implements Initializable {
    private DayOfWeek localDate = LocalDate.now().getDayOfWeek();
    private String dayNow = getDay(localDate);
    private final List<String> WEEK_DAY = new ArrayList<>(Arrays.asList("Понедельник", "Вторник", "Среда", "Четверг", "Пятница", "Суббота", "Воскресенье"));
    private int i = 0;
    private int j = WEEK_DAY.indexOf(dayNow);
    private LocalDate localDate1 = LocalDate.now();
    @FXML
    private Label daylb;

    @FXML
    private Label hourlb;
    @FXML
    private Label weatherlb;
    @FXML
    private Label temperaturelb;
    @FXML
    private Label pressurelb;

    @FXML
    private Label windlb;

    @FXML
    private Label humiditylb;

    private static File file = new File("src/main/resources/weather.json");
    public static List<DateWeather> dateWeathers = new ArrayList<>();

    private static Document getPage() throws IOException {
        String url = "https://world-weather.ru/pogoda/russia/ryazan/7days/";
        Document page = Jsoup.parse(new URL(url), 3000);
        return page;
    }

    /**
     * Преобразование списка обектов в json файл
     *
     * @param list
     * @return
     */
    private static String getJsonWeather(List<DateWeather> list) {

        ObjectMapper objectMapper = new ObjectMapper();
        String result = "ok";
        try {
            objectMapper.writeValue(file, list);
        } catch ( IOException e ) {
            System.out.println("что-то пошло не так.");
            throw new RuntimeException(e);
        }
        return result;
    }

    private static String getDay(DayOfWeek dayOfWeek) {
        String day = String.valueOf(dayOfWeek);
        String result = "";
        switch (day) {
            case ("MONDAY"):
                result = "Понедельник";
                break;
            case ("TUESDAY"):
                result = "Вторник";
                break;
            case ("WEDNESDAY"):
                result = "Среда";
                break;
            case ("THURSDAY"):
                result = "Четверг";
                break;
            case ("FRIDAY"):
                result = "Пятница";
                break;
            case ("SATURDAY"):
                result = "Суббота";
                break;
            case ("SUNDAY"):
                result = "Воскресенье";
                break;
        }
        return result;
    }

    private void timeNow() {
        Thread thread = new Thread(() -> {
            SimpleDateFormat sdf = new SimpleDateFormat("hh:mm:ss");
            while (true) {
                try {
                    Thread.sleep(1000);
                } catch ( InterruptedException e ) {
                    throw new RuntimeException(e);
                }
                String timeNow = sdf.format(new Date());
                Platform.runLater(() -> {
                    hourlb.setText(timeNow);
                });
            }
        });
        thread.start();
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println(dayNow);
        timeNow();
        Document page = null;
        try {
            page = getPage();
        } catch ( IOException e ) {
            throw new RuntimeException(e);
        }
        Element allPage = page.select("div[id=content-left]").first();
        Elements days = allPage.select("div[class=weather-short]");

        for (Element elem : days) {
            String date1 = elem.select("div[class = dates short-d red]").text();
            String date = elem.select("div[class = dates short-d]").text();
            StringBuilder sb = new StringBuilder();

            System.out.print(sb.append(date1).append(date)
                    .append(" -   Погода   Температура     Давление     Ветер     Влажность").append("\n"));
            StringBuilder sb1 = new StringBuilder();

            //беру только данные времени суток - День
            String weather = elem.select("td[ class = weather-temperature]")
                    .attr("div", "title").get(2).child(0).attr("title");
            String temperature = elem.select("td[class = weather-temperature]").get(2).text();
            String pressure = elem.select("td[class = weather-pressure]").get(2).text();
            String wind = elem.select("td[ class = weather-wind]")
                    .attr("span", "title").get(2).child(0).attr("title");
            String humidity = elem.select("td[class = weather-humidity]").get(2).text();
            System.out.println(sb1.append("                     ").append(weather).append("     ")
                    .append(temperature).append("          ").append(pressure).append("     ")
                    .append(wind).append("     ").append(humidity).append("\n"));
            dateWeathers.add(new DateWeather(weather, temperature, pressure, wind, humidity));
        }
        for (DateWeather d : dateWeathers) {
            System.out.println(d);
        }
        System.out.println("Очищаем список.");
        getJsonWeather(dateWeathers);
        dateWeathers.clear();
        //чтение json  файла и запись данных в список обектов
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            dateWeathers = objectMapper.readValue(file, new TypeReference<List<DateWeather>>() {
            });
        } catch ( IOException e ) {
            throw new RuntimeException(e);
        }
    }

    public void nextDay(ActionEvent actionEvent) {
        checkListSize(i, j);
        int num[] = checkListSize(i, j);
        i = num[0];
        j = num[1];
        setLabel(i, j);
        ++i;
        ++j;
    }

    public void backDay(ActionEvent actionEvent) {
        --i;
        --j;
        int num[] = checkListSize(i, j);
        i = num[0];
        j = num[1];
        setLabel(i, j);
    }

    public void setLabel(int i, int j) {
       // System.out.println(dateWeathers.size());
        String day = WEEK_DAY.get(j);
        daylb.setText(day);
        weatherlb.setText(dateWeathers.get(i).getWeather());
        temperaturelb.setText(dateWeathers.get(i).getTemperature());
        pressurelb.setText(dateWeathers.get(i).getPressure());
        windlb.setText(dateWeathers.get(i).getWind());
        humiditylb.setText(dateWeathers.get(i).getHumidity());
    }

    public int[] checkListSize(int t, int m) {
        int[] numbers = new int[2];
        if (t < 0) {
            t = dateWeathers.size() - 1;
        }
        if (t > dateWeathers.size() - 1) {
            t = 0;
        }
        if (m < 0) {
            m = WEEK_DAY.size() - 1;
        }
        if (m > WEEK_DAY.size() - 1) {
            m = 0;
        }
        numbers[0] = t;
        numbers[1] = m;
        return numbers;
    }
}
